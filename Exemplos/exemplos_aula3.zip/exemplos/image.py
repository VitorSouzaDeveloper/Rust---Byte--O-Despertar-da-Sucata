import pygame

pygame.init()
screen = pygame.display.set_mode((640, 360))
clock = pygame.time.Clock()
running = True

# Variáveis para o controle do tempo de 1 segundo
tempo_ultimo_segundo = pygame.time.get_ticks()

surface = pygame.image.load("assets/image/player.png").convert_alpha()
#surface = pygame.transform.smoothscale_by(surface, 5)
#surface = pygame.transform.rotozoom(surface, 90, 5)

# Criar o retângulo inicial e definir a posição do centro na tela
rect = surface.get_rect(center=(300, 200))
print(rect)
#angulo = 0

#surface.fill((255,0,0))

while running:    
    for event in pygame.event.get():        
        if event.type == pygame.QUIT:
            running = False

    screen.fill("black")

    # Aumentar o ângulo de rotação
    #angulo += 2

    # 2. Medir o tempo atual
    tempo_atual = pygame.time.get_ticks()

    # 3. Verificar se passou 1 segundo (1000 milissegundos)
    if tempo_atual - tempo_ultimo_segundo >= 1000:
        #print("Passou 1 segundo!")       
        surface = pygame.transform.rotate(surface, 5)
        # 3. Atualizar o rect mantendo o mesmo centro da posição anterior
        rect = surface.get_rect(center=rect.center)
        # Reseta o temporizador para o próximo segundo
        tempo_ultimo_segundo = tempo_atual

    #desenhe algo
    screen.blit(surface, rect.topleft)


    pygame.display.flip()
    clock.tick(60)

pygame.quit()
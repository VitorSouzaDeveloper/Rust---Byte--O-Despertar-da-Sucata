import pygame

pygame.init()
#flags = pygame.SCALED | pygame.FULLSCREEN
flags = 0
size = (3840, 2160)
screen = pygame.display.set_mode(size, flags)
clock = pygame.time.Clock()
running = True

# Variáveis para o controle do tempo de 1 segundo
tempo_ultimo_segundo = pygame.time.get_ticks()

# Initialize a font (system default or custom font file)
#font = pygame.font.SysFont("arial", 50)
font = pygame.font.Font("assets/fonts/Call of Ops Duty II.otf", 50)
#font = pygame.font.Font("assets/fonts/FreeSans.ttf", 50)

fps_text = f"FPS:{str(int(clock.get_fps()))}"
fps_surface = font.render(fps_text, True, pygame.Color("white"))


while running:    
    for event in pygame.event.get():        
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

    screen.fill("black")

    
    # 2. Medir o tempo atual
    tempo_atual = pygame.time.get_ticks()

    # 3. Verificar se passou 1 segundo (1000 milissegundos)
    if tempo_atual - tempo_ultimo_segundo >= 1000:
        print("Passou 1 segundo!")
        fps_text = f"FPS:{str(int(clock.get_fps()))}"
        fps_surface = font.render(fps_text, True, pygame.Color("white")) 
        
        # Reseta o temporizador para o próximo segundo
        tempo_ultimo_segundo = tempo_atual

    #desenhe algo
    screen.blit(fps_surface, (size[0]//2, size[1]//2))
   

    pygame.display.flip()
    clock.tick(0)

pygame.quit()